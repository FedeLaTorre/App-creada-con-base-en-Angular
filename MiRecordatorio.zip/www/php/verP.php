<?php header("Access-Control-Allow-Origin: *");
$parciales = array(
    array ("materia" => "Dispositivos moviles", "profesor" => "Mabel Garcia",
          "hora" => "Segunda hora", "fecha" => "18/06"),
    array ("materia" => "Programación 2", "profesor" => "Santiago Gallino",
          "hora" => "Primer hora", "fecha" => "25/06"),
    array ("materia" => "Experiencia del usuario", "profesor" => "Valeria Meijide","hora" => "Segunda hora", "fecha" => "21/06"),
    array ("materia" => "Diseño Interactivo", "profesor" => "Jonatan Jorge",
          "hora" => "Primer hora", "fecha" => "28/06"),
    array ("materia" => "Sistemas Operativos", "profesor" => "Guillermo Stancanelli", "hora" => "Segunda hora", "fecha" => "27/06")

);
echo json_encode($parciales);
