 var miapp = angular.module('miApp', ['ngRoute', 'mobile-angular-ui']);

miapp.config(function ($routeProvider) {
    $routeProvider.when('/', {
        templateUrl: 'secciones/home.html',
        reloadOnSearch: false,
        controller: 'home'
    });
    $routeProvider.when('/verP', {
        templateUrl: 'secciones/verP.html',
        reloadOnSearch: false,
        controller: 'parciales'
    });
    $routeProvider.when('/verM', {
        templateUrl: 'secciones/verM.html',
        reloadOnSearch: false,
        controller: 'parciales',
        
    });
     $routeProvider.when('/materiasA', {
        templateUrl: 'secciones/materiasA.html',
        reloadOnSearch: false,
        controller: 'materiasA',
        
    });
    $routeProvider.otherwise({
        redirectTo: '/'
    });
});

miapp.controller("home", function ($scope) {
    $scope.mensaje = "Acá podran organizar y ver sus próximos parciales.";
});

miapp.controller("materia", function ($scope) {
    $scope.materia = "Materia";
});
miapp.controller("profesor", function ($scope) {
    $scope.profesor = "Profesor";
});
miapp.controller("hora", function ($scope) {
    $scope.hora = "Hora";
});



miapp.controller("parciales", function ($scope, $http) {
    $scope.mostrar = [];
   // $http.get("php/verP.php")
	$http.get("http:///latorreparcial.atwebpages.com/verP.php")
        .then(function exito(respuesta) {
                localStorage.setItem("items", angular.toJson(respuesta.data));
				
                $scope.mostrar = respuesta.data;
				
        
            }, function error(respuesta) {
				if (localStorage.items != "undefined" && localStorage.items != null){
					$scope.noconexion = angular.fromJson(localStorage.getItem("items")); 
						
					}
			}
            )
        });


miapp.controller("materiasA", function ($scope) {
	if(!localStorage.getItem("materiasApr")){
	
	$scope.materias = [
		{ materia :"Dispositivos moviles", 
			profesor :"Mabel Garcia",  
			},
		{ materia :"Programación 2", 
			profesor:"Santiago Gallino", 
			},
		{ materia:"Experiencia del usuario", 
			profesor:"Valeria Meijide" , 
			},
		{ materia :"Diseño Interactivo", 
			profesor:"Jonatan Jorge", 
			},
		{ materia :"Sistemas Operativos", 
			profesor:"Guillermo Stancanelli", 
			}
		]
	}else{
		$scope.materias= JSON.parse(localStorage.getItem('materiasApr'));
	}
	
//FAVORITOS	
	$scope.aprobadas = function(item){
		$scope.nuevo_obj={materia :item.materia, profesor :item.profesor, selected: true}
		
		localStorage.setItem("materiasApr", JSON.stringify($scope.materias));
		
	};
});
